Programmbeschreibung:

"Algorithm_Visualizer" ist ein Programm, welches dabei helfen soll die, folgenden
Sortieralgorithmen besser lernen zu können.:

- bubble sort
- selection sort
- insertion sort

Das Programm bietet die Möglichkeit an diese Algorithmen mithilfe von Blöcken
darzustellen, deren Höhe den Wert eines Arrays widerspiegeln. Diese Höhen/Werte/Blöcke
werden dann schließlich, mithilfe einer der, von dem Nutzer selbst ausgewählten, Algorithmen,
sortiert, was zu einem besseren Verständnis des Nutzers bezüglich der Algorithmen führen soll.
Des Weiteren kann der Nutzer die dargestellten Blöcke zufällig aufstellt, womit man
die Algorithmen in unterschiedlichen Anordnungen der Blöcke in 
Aktion sehen kann.
Falls die dargestellten Algorithmen nicht verstanden werden konnten, besitzt der Nutzer zusätzlich
die Möglichkeit sich innerhalb des Programms über die Algorithmen zu informieren.


Welche Anforderungen besitzt das Programm?

Sie sollten mindesten Java 1.8 und Windows auf ihrem Rechner installiert haben, um dieses Programm
korrekt ausführen zu können.


Wie starte ich das Programm?

Um das Programm zu starten, müssen Sie auf die Datei "Algorithm_Visualizer.jar" doppelklicken.


Wie benutzte ich das Programm?

Mit der Auswahlleiste, die sich in der linken-unteren Ecke des Programms befindet, können Sie ihren
gewünschten Algorithmus auswählen.
Des Weiteren stellen Sie alle Blöcke unterschiedlich auf, bei dem Klick auf den Kopf "NEW".
Der ausgewählte Algorithmus wird mit dem Klick auf den Knopf "RUN" ausgeführt.
Die zwei Textfelder, die sich über der Auswahlleiste der Algorithmen
befinden, geben Ihnen an, ob und wann der Algorithmus am Laufen ist und wann die Sortierung beendet wurde.
Die Textfelder zeigen auch an, wie oft der Algorithmus zwei Blöcke getauscht hat.
Die obere Menüleiste des Programms ist in drei Untermenüs eingeteilt: "Options", "Help" und "Contact".
Mit dem Klick auf "Exit" des Untermenüs "Options", schließen Sie das Programm.
Alle Themen des Untermenüs "Help" bieten Ihnen die Möglichkeit die oben erwähnten Informationen
über die genannten Sortieralgorithmen zu erfahren. 
Das Thema "via GitHub" des Untermenüs "Contact" ermöglicht Ihnen den Programmierer des Programms,
bei Fehlern des Programms oder bei Fragen bezüglich des Programms,
über GitHub zu informieren bzw. zu kontaktieren.
Klicken Sie für weitere wichtige Informationen über das Programm auf den Knopf "Info!".




